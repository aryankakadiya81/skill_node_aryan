const express = require("express");
const app = express();
const PORT = 1000;

app.get("/",(req,res) => {
    res.json({msg : "Hello"})
    console.log("Hello");
})

app.listen(PORT,() => {
    console.log(`server listenin port ${PORT}`)
})
// localhost:1000

// .get +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// const express = require("express");
// const app = express();
// const PORT = 1000;

// app.get("/Login",(req,res) => {
//     res.json({msg : "login"})
//     console.log("Hello");
// })
// app.listen(PORT,() => {
//     console.log(`server listenin port ${PORT}`)
// })
// localhost:1000/Login

// .post +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// browser not supported for now

// const express = require("express");
// const app = express();
// const PORT = 1000;

// app.post("/Login",(req,res) => {
//     res.json({msg : "login post"})
//     console.log("Hello");
// })

// app.listen(PORT,() => {
//     console.log(`server listenin port ${PORT}`)
// })

// localhost:1000/Login



