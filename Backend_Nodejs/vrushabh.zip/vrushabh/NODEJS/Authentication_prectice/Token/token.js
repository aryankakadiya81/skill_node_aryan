const tokenObj = {
    token: ""
};

module.exports = tokenObj;