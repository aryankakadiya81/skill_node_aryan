/*** Write a python function that accepts a number as a parameter and check the number is prime or not. ***/

/*** Named Function ***/

const prompt = require("prompt-sync")();

/* function PrimeNumber(number) {

        if (number == 1) {
        return "1 is Constant."
    }
    else if (number > 1) {
        for (let i = 2; i < number; i++) {
            if (number % i == 0) {
                return '${number} is not a prime';
            }
        }
        return '${number} is prime number.';
    }
}

let number = parseInt(prompt("Enter a value : "));
console.log(PrimeNumber(number)); */

/*** Anonymous Function ***/

/* let PrimeNumber = (number) => {

    if (number == 1) {
        return "1 is Constant."
    }
    else if (number > 1) {
        for (let i = 2; i < number; i++) {
            if (number % i == 0) {
                return '${number} is not a prime';
            }
        }
        return '${number} is prime number.';
    }
}

let number = parseInt(prompt("Enter a value : "));
console.log(PrimeNumber(number)); */


